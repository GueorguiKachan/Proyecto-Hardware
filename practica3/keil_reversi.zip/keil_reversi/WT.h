#ifndef WT_H
#define WT_H

void WD_init(int sec);
void WD_feed();

#endif