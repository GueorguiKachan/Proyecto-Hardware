#ifndef RTC_H
#define RTC_H

void RTC_init(void);
int RTC_leer_minutos(void);
int RTC_leer_segundos(void);

#endif