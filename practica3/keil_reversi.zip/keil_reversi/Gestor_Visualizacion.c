#include <LPC210x.H> 
#include "Gestor_Visualizacion.h"
#include "cola.h"
#include <stdlib.h>
#include <string.h>
#include "eventos.h"
#define CR     0x0D

static int index;
static int tamanyo_string;
char * mensaje_inicial;
char mensaje_reglas[] = "Jugada: #FilaColumnaValorChecksum!, donde checksum = Fila + Columna + Valor % 8";
char *buffer_string;
static int fin = 0;

void uart0_ISR (void) __irq{
		
	if(((U0IIR >> 1) & 0x111) == 1 ){
		if(fin != 1){
		cola_guardar_eventos(cout_caracter,0);
		}else{
			continuar_mensaje();
		}
	}	
	else{
		uint32_t hola = U0RBR;
		VICVectAddr = 0;
		cola_guardar_eventos(nuevo_caracter,hola);
	}
}


	
void init_serial (void)  {               /* Initialize Serial Interface       */
  PINSEL0 |= 0x00000005;                  /* Enable RxD1 and TxD1              */ //RxD1 =  Receiver input for UART1 //TxD1 =  Transmitter output for UART1 // UART0 --> 0x00000005
  U0LCR = 0x83;                          /* 8 bits, no Parity, 1 Stop bit     */
  U0DLL = 97;                            /* 9600 Baud Rate @ 15MHz VPB Clock  */
  U0LCR = 0x03;                          /* DLAB = 0                          */
	U0IER = 0x07; //es de 32bits
	VICVectAddr13= (unsigned long)uart0_ISR;
	VICVectCntl13 = 0x20 | 6;     
	VICIntEnable = VICIntEnable | 0x00000040;                  // Enable Timer0 Interrupt
	//VICIntSelect = VICIntSelect | 0x00000080; 
}

int sendchar (int ch)  {                 /* Write character to Serial Port    */

  /*if (ch == '\n')  {
    while (!(U1LSR & 0x20));
    U1THR = CR;                           output CR */
  //}
  while (!(U0LSR & 0x20));
  return (U0THR = ch);
}



void Gvisualizacion_print_array(int lista[]){
	int i;
	int size;
	int value = 0;
	size = 380;
	for(i = 0; i <= size; i++){
		sendchar(lista[i]);
	}
	//sendchar('n');
}
void enviar_string(char *mensaje){
	if(index == 0){ // Ya se ha acabado de copiar lo que se ten�a que copiar
	//index = 0;
		buffer_string = mensaje;
		
		if(buffer_string[index] == '+'){
			tamanyo_string = 380;
		}
		sendchar(buffer_string[index]);
		index++;
	
	}
	else{ // Todavia faltan cosas del antiguo string por copiar
		if(mensaje[0] == '+'){
			tamanyo_string += 380;
		}
		strcat(buffer_string,mensaje);
		sendchar(buffer_string[index]);
		index++;
	}
}

void continuar_mensaje(){
	int val = buffer_string[index];
	if(index < tamanyo_string){
		if(val != '\0'){
		
			sendchar(buffer_string[index]);
			index++;
		}else{
			if(fin ==1 ){
				fin = 2;
			}
			index =  0;
			tamanyo_string = 0;
		}
	}
	else{
		index = 0;
		tamanyo_string = 0;
	}
}
	
void mensaje_inicial_print(){
	static char explicacion_juego[] =  "Juego sudoku 9x9:\n El mismo numero no puede estar en la misma fila columna o cuadrado\n";
	static char explicacion_simbolos[] = " ~: El valor es una pista(no se modifica) --- >: Es un nuevo valor a introducir\n";
	static char explicacion_inicio[] = " Para empezar la partida escribir #NEW! en el uart o pulsar cualquier boton\n";
	static char explicacion_reset[] = " Para acabar la partida escribir #RST! en la uart\n";
	static char explicacion_jugada[] = " Introducir una jugada: #ABCD! donde: A = fila, B = columna, C = nuevo valor D = A+B+C % 8 \n";
	static char explicacion_aceptar[] = " Tras introducir la jugada, pulsar eint0 para aceptarla o eint1 para cancelar.\n";
	static char explicacion_jugada_anulada[] = " Si tras 3 segundos no se toma una decisi�n la jugada queda anulada.\n";
	int longitud_mensaje = sizeof(explicacion_inicio) + sizeof(explicacion_juego) + sizeof(explicacion_jugada) + 
													sizeof(explicacion_reset)+sizeof(explicacion_simbolos)+sizeof(explicacion_aceptar) + sizeof(explicacion_jugada_anulada);

	strcat(explicacion_juego,explicacion_simbolos);
	strcat(explicacion_juego,explicacion_inicio);
	strcat(explicacion_juego,explicacion_reset);
	strcat(explicacion_juego,explicacion_jugada);
	strcat(explicacion_juego,explicacion_aceptar);
	strcat(explicacion_juego,explicacion_jugada_anulada);
	index = 0;
	tamanyo_string = longitud_mensaje;
	buffer_string = explicacion_juego;
	sendchar(buffer_string[index]);
	index++;
}
void enviar_mensaje_final(int minutos, int segundos){
	static char mins[2];
	static char secs[2];
	static char m[] = " minutos y ";
	static char s [] = " segundos. \n";
	static char explicacion_final[] =  "Fin de la partida despues de "; //+ itoa(minutos) + " minutos y " + segundos + " segundos."
	sprintf(mins,"%d",minutos);
	sprintf(secs,"%d",segundos);
	//strcat(explicacion_final,mins);
	//strcat(explicacion_final, m);
	//strcat(explicacion_final,secs);
	//strcat(explicacion_final,s);
	
	strcat(mins,m);
	strcat(mins,secs);
	strcat(mins,s);
	
	buffer_string = mins;//explicacion_final;
	index = 0;
	tamanyo_string = sizeof(mins);
	sendchar(buffer_string[index]);
	fin = 1;
}

bool fin_m_final(){
	if( fin == 2){
		return true;
	}
	else{
		return false;
	}
}