#include <LPC210x.H> 
#define CR     0x0D

void init_serial (void)  {               /* Initialize Serial Interface       */
  PINSEL0 = 0x00050000;                  /* Enable RxD1 and TxD1              */ //RxD1 =  Receiver input for UART1 //TxD1 =  Transmitter output for UART1 // UART0 --> 0x00000005
  U1LCR = 0x83;                          /* 8 bits, no Parity, 1 Stop bit     */
  U1DLL = 97;                            /* 9600 Baud Rate @ 15MHz VPB Clock  */
  U1LCR = 0x03;                          /* DLAB = 0                          */
}

static int sendchar (int ch)  {                 /* Write character to Serial Port    */

  /*if (ch == '\n')  {
    while (!(U1LSR & 0x20));
    U1THR = CR;                          /* output CR */
  //}
  while (!(U1LSR & 0x20));
  return (U1THR = ch);
}

void Gvisualizacion_print_array(int lista[]){
	int i;
	int size;
	int value = 0;
	size = 380;
	for(i = 0; i <= size; i++){
		sendchar(lista[i]);
	}
}

