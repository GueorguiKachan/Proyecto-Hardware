enum {alarmaSet =0,
      pulsacion1 = 1,
      pulsacion2 =2,
			tempPeriodico =3,
			PDown =4,
			visualizar =5,
			apagarValidacion =6,};