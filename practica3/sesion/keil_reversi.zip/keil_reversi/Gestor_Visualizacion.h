#ifndef GESTOR_VISUALIZACION_H
#define GESTOR_VISUALIZACION_H

void init_serial(void);

void Gvisualizacion_print_array(int lista[]);

#endif