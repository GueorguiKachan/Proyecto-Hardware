#include "gestor_IO.h"
#include "gestorGPIO.h"
#include <stdint.h>
#include "eventos.h"
#include "cola.h"

static uint8_t fila_actual = 10 ,columna_actual = 10;

void gestorIO_iniciar(){
	uint32_t eventoVisualizar;
	GPIO_iniciar();
	GPIO_marcar_salida(0,14);
	GPIO_marcar_entrada(16,12);
	GPIO_marcar_salida(30,2);
	eventoVisualizar = visualizar; // Todo lo necesario para la alarma de un evento visualizar
	eventoVisualizar = eventoVisualizar <<24;
	eventoVisualizar = eventoVisualizar | 0x00800000;
	eventoVisualizar = eventoVisualizar + 200;
	
	cola_guardar_eventos(alarmaSet,eventoVisualizar);
}

void gestorIO_guardar_fila_columna_actual(uint8_t fila_nueva, uint8_t columna_nueva){
	fila_actual = fila_nueva;
	columna_actual = columna_nueva;
}

bool gestorIO_visualizar(){
	int fila = gestorIO_leer_fila();
	int col = gestorIO_leer_columna();
	if (fila_actual != fila || columna_actual != col){
		gestorIO_guardar_fila_columna_actual(fila,col);
		return true;
	}
	return false;
}

int gestorIO_leer_fila(){ 
	return GPIO_leer(16,4);
}
void gestorIO_escribir_fila(int valor){
	GPIO_escribir(16,4,valor);
}

int gestorIO_leer_columna(){
	return GPIO_leer(20,4);
}
void gestorIO_escribir_columna(int valor){
	GPIO_escribir(20,4,valor);
}

int gestorIO_leer_valor_celda(){
	return GPIO_leer(0,4);
}
void gestorIO_escribir_valor_celda(int valor){
	GPIO_escribir(0,4,valor);
}

int gestorIO_leer_valor_nuevo(){
	return GPIO_leer(24,4);
}
void gestorIO_escribir_valor_nuevo(int valor){
	GPIO_escribir(24,4,valor);
}

int gestorIO_leer_candidatos(){
	return GPIO_leer(4,9);
}
void gestorIO_escribir_candidatos(int valor){
	GPIO_escribir(4,9,valor);
}

int gestorIO_leer_error(){
	return GPIO_leer(13,1);
}
void gestorIO_escribir_error(int valor){
	GPIO_escribir(13,1,valor);
}

void gestorIO_escribir_overflow(int valor){
	GPIO_escribir(30,1,valor);
}

void gestorIO_escribir_idle(int valor){
	GPIO_escribir(31,1,valor);
}
