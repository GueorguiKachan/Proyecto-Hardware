#include "Gestor_pulsacion.h"
#include "eventos.h"
#include <stdint.h>
#include "cola.h"
#include <LPC210X.H>
#include "buttons.h"

void gestor_pulsacion_inicializar_botones(){
	buttons_init();
}

bool gestor_pulsacion_eint1_comprobar_sigue_pulsado(){
	//si el boton sigue pulsado
	if (buttons_eint1_estado()){
		return true;
	}
	return false;
}

bool gestor_pulsacion_eint2_comprobar_sigue_pulsado(){
	//si el boton sigue pulsado
	if (buttons_eint2_estado()){	
		return true;
	}
	return false;
}



