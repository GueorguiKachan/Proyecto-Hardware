#ifndef COLA_H
#define COLA_H

#include <stdint.h>
#include <stdbool.h>

void cola_guardar_eventos(uint8_t ID_evento, uint32_t auxData);
bool cola_eliminar_evento_mas_antiguo();
bool cola_hay_eventos();
uint8_t cola_leer_evento_mas_antiguo();
uint32_t cola_leer_datos_aux_mas_antiguo();

#endif