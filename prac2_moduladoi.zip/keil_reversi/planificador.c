#include <LPC210x.H>                       /* LPC210x definitions */
#include <stdio.h>
#include "timers.h"
#include "eventos.h"
#include "cola.h"
#include "Gestor_Alarmas.h"
#include "Gestor_Energia.h"
#include "Gestor_Pulsacion.h"
#include "Gestor_IO.h"
#include "sudoku_2021.h"
#include "tableros.h"

#define filaColumnaSudoku 9

int main (void) {
bool powerDownActive = false;
while(1){
	bool idleCambiado = false;
	bool idleRecienApagado = false;
	bool valorCambiado = false;
	int eventoPD;
	int eventoVisualizar;
	int apagarVal;
	int evento;
	int tiempoAntes;
	uint8_t evento_id;
	int tiempo;
	bool pulsacion1_recien_pulsado = true;
	bool pulsacion2_recien_pulsado = true;
	//struct elemento aux;
	int i, j;
	
	temporizador_iniciar();
	temporizador_empezar();
  // Programar alarma peri�dica para encolar un evento de tipo tempPeriodico
	sudoku_init();
  GestorAlarmaInit();
	gestorIO_iniciar();
	gestor_pulsacion_inicializar_botones();
	gestor_energia_init();
	
	apagarVal = apagarValidacion; // Todo lo necesario para la alarma de un evento para apagar la validaci�n
	apagarVal = apagarVal <<24;
	apagarVal = apagarVal + 1000;
	
	while(1){
    if(cola_hay_eventos()){ // Comprueba si en la cola hay eventos nuevos. Si los hay averigua cual es
			evento_id = cola_leer_evento_mas_antiguo();
			cola_eliminar_evento_mas_antiguo();
			
			if(evento_id == alarmaSet){														// Programar alarma nueva
				gestor_alarma_nueva_alarma(cola_leer_datos_aux_mas_antiguo());
			}
			else if(evento_id == pulsacion1){											// Se pulsa el bot�n eint1
				if(pulsacion1_recien_pulsado){
					if(!powerDownActive){
						tiempoAntes = temporizador_leer();
						//falta comprobar si todo es 0
						sudoku_anyadir_valor_nuevo(gestorIO_leer_fila(),gestorIO_leer_columna(),gestorIO_leer_valor_nuevo());
						tiempo = temporizador_leer() - tiempoAntes;
						valorCambiado=true;
						gestorIO_escribir_error(1);
						idleCambiado = true;
						cola_guardar_eventos(alarmaSet,apagarVal); // Tras 1 segundo, apagar bit de validaci�n
					}
					else{ 
						powerDownActive = false;
						gestorIO_escribir_idle(0);// Aqu� habr�a que encender el bot�n de error mejor no?
					}
					cola_guardar_eventos(alarmaSet,eventoPD);
					pulsacion1_recien_pulsado = false;
				}
				if (!gestor_pulsacion_eint1_comprobar_sigue_pulsado()){
					pulsacion1_recien_pulsado = true;
				}
		}
		else if(evento_id == pulsacion2){										// Se pulsa el bot�n eint2
				if (pulsacion2_recien_pulsado){ //Si se ha dejado de pulsar
					if(!powerDownActive){ //Comprobar si se ha pulsado el bot�n para salir de modo Power Down
						tiempoAntes = temporizador_leer();
						sudoku_borrar_valor(gestorIO_leer_fila(),gestorIO_leer_columna());
						tiempo = temporizador_leer() - tiempoAntes;
						valorCambiado=true;
						gestorIO_escribir_error(1);
						idleCambiado = true;
						cola_guardar_eventos(alarmaSet,apagarVal); // Tras 1 segundo, apagar bit de validaci�n
					}
					else{ 
						powerDownActive = false;
						gestorIO_escribir_idle(0);// Aqu� habr�a que encender el bot�n de error mejor no?
					}
				cola_guardar_eventos(alarmaSet,eventoPD);
			}
			if (!gestor_pulsacion_eint2_comprobar_sigue_pulsado()){
					pulsacion2_recien_pulsado = true;
			}
		}
			else if(evento_id == tempPeriodico){                 // Temporizador peri�dico. Comprobar si alguna alarma salta
				gestor_alarma_restar_tiempo_alarmas_programadas(); // El temporizador interrumpe cada 1ms. Creo que en vez de 1000 hay que poner 1
			}
			else if(evento_id == PDown){													// Poner el sistema en modo PowerDown
				powerDownActive = 1;
				gestorIO_escribir_idle(1);
				PM_power_down();
			}
			else if(evento_id == visualizar){											// Actualizar el valor de la celda y sus candidatos en la GPIO
				if (gestorIO_visualizar() || valorCambiado || idleRecienApagado){
					cola_guardar_eventos(alarmaSet,eventoPD);
					if(sudoku_fila_columna_validos(gestorIO_leer_fila(),gestorIO_leer_columna())){
						gestorIO_escribir_valor_celda(sudoku_get_valor_celda(gestorIO_leer_fila(), gestorIO_leer_columna()));
						if (!idleCambiado){ //Durante el segundo de validaci�n, esta bit tiene que estar siempre encendido
							gestorIO_escribir_error(sudoku_get_valor_error(gestorIO_leer_fila(), gestorIO_leer_columna()));
						}
						gestorIO_escribir_candidatos(sudoku_get_valor_candidatos(gestorIO_leer_fila(), gestorIO_leer_columna()));
				
				}		
					}

					valorCambiado= false;
					idleRecienApagado = false;
				
			}
			else if(evento_id == apagarValidacion){								// Tras un segundo apagar el bit de validacion
				idleCambiado= false;
				idleRecienApagado = true;
				gestorIO_escribir_error(0);
			}
			else{} // El valor del evento no coincide con ninguno de los registrados
		}
      else{
				gestorIO_escribir_idle(1);
        PM_idle(); // Poner el procesador en modo reposo hasta que llegue la interrupci�n del temporizador
				gestorIO_escribir_idle(0);
			}
    }
		temporizador_parar();
		PM_power_down(); // Modo Power Down cuando acaba una partida, hasta que se pulse un bot�n
		powerDownActive = true;
	}
}

