extern void temporizador_iniciar(void);
extern void temporizador_empezar(void);
extern unsigned int temporizador_leer(void);
extern unsigned int temporizador_parar();
void temporizador_periodico (int periodo);
