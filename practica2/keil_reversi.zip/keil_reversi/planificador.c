#include <LPC210x.H>                       /* LPC210x definitions */
//#include "Timer.h"
//#include "Power_management.h"
//#include "boton_eint0.h"
#include <stdio.h>
#include "timers.h"
#include "eventos.h"
#include "cola.h"
#include "Gestor_Alarmas.h"
#include "Gestor_Energia.h"
#include "Gestor_Pulsacion.h"
#include "gestorGPIO.h"

int main (void) {
	int evento;
	struct elemento aux;
  // Programar alarma peri�dica para encolar un evento de tipo tempPeriodico
  limpiarEspacio();
	GPIO_iniciar();
	temporizador_periodico(3); // 14999 = 1ms
  evento = PDown;
	evento = evento <<24;
	evento = evento | 0x00800000;
	evento = evento + 15000;
	cola_guardar_eventos(alarmaSet,evento);
	
	evento = visualizar;
	evento = evento <<24;
	evento = evento | 0x00800000;
	evento = evento + 200;
	cola_guardar_eventos(alarmaSet,evento);
	
	
	GPIO_marcar_salida(0,14);
	GPIO_marcar_entrada(16,12);
	GPIO_marcar_salida(30,2);
	
	
	while(1){
		
    if(hay_eventos()){ // Comprueba si en la cola hay eventos nuevos. Si los hay --> switch-case
			aux = elementoMasAntiguo();
			eliminar();
			if(aux.ID_evento == alarmaSet){
				evento = aux.auxData;
				 nuevoEvento(evento);
			}
			else if(aux.ID_evento == pulsacion1){
				eint1_comprobar();
				evento = PDown;
				evento = evento <<24;
				evento = evento | 0x00800000;
				evento = evento + 15000;
				cola_guardar_eventos(alarmaSet,evento);}
			else if(aux.ID_evento == pulsacion2){
				eint2_comprobar();
				evento = PDown;
				evento = evento <<24;
				evento = evento | 0x00800000;
				evento = evento + 15000;
				cola_guardar_eventos(alarmaSet,evento);}
			else if(aux.ID_evento == tempPeriodico){
				disparaEventos(1); // El temporizador interrumpe cada 1ms. Creo que en vez de 1000 hay que poner 1
				
			}
			else if(aux.ID_evento == PDown){
				GPIO_escribir(31,1,1);
				PM_power_down();
			}
			else if(aux.ID_evento == visualizar){
				//visualizar todo
			}
			else if(aux.ID_evento == nuevaInfo){
				//Introducir datos
			}
			else{}
      /*switch(evento)
			{
        case alarmaSet: // Programar una alarma con la info extra del evento
          nuevoEvento(leerDatosMasAntiguo());
					break;
        case pulsacion1: 
					break;
        case pulsacion2:
					break;
        case tempPeriodico: // Establecer un temporizador periodico
          disparaEventos(1000); // El temporizador interrumpe cada 1us = 1000ms (en el Gestor los tiempos de alarma se guardan en ms)
					break;
				case compruebaSuelta1: //Comprobar si se ha soltado la tecla 
          break;
					//eint1_comprobar();
        case compruebaSuelta2:
          //eint2_comprobar();
					break;
				default:
					break;
      }*/
		}
      else{
        PM_idle(); // Poner el procesador en modo reposo hasta que llegue la interrupci�n del temporizador
      }
    }
	}
