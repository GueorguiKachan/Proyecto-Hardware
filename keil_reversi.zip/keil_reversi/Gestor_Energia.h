void PM_power_down (void);  
extern void Switch_to_PLL();
void PM_idle(void);