#ifndef BUTTONS_H
#define BUTTONS_H
#include <stdbool.h>
void buttons_init();
bool buttons_eint1_estado();
bool buttons_eint2_estado();
#endif