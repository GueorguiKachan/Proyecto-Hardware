#ifndef GESTOR_VISUALIZACION_H
#define GESTOR_VISUALIZACION_H

#include <stdbool.h>

void init_serial(void);
int sendchar (int ch) ;
void Gvisualizacion_print_array(int lista[]);
void mensaje_inicial_print();
void enviar_string(char *mensaje);
void continuar_mensaje();
void enviar_mensaje_final(int minutos, int segundos);
bool fin_m_final();
#endif