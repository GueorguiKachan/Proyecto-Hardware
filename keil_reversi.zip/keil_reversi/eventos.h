#define alarmaSet 0
#define pulsacion1 1
#define pulsacion2 2
#define tempPeriodico 3
#define compruebaSuelta 4
#define PDown 5 //--> Se programa alarma de 15 segundos que gemera el evento de power down
#define visualizar 6
#define apagarValidacion 7