#include <LPC210X.H>
#include "WT.h"
#include "cola.h"
#include "eventos.h"
#include "timers.h"

void WD_init(){
	if( WDMOD & 0x04 ) {					   /* Check for watchdog time out. El bit 2 se activa si se ha disparado el watchdog*/
  
		WDMOD &= ~0x04;						   /* Clear time out flag           */
		cola_vaciar();
		cola_guardar_eventos(wt_reiniciar_juego,0);
	}
	WDTC  = 0x11E1A300;						   // Set watchdog time out value
  WDMOD = 0x03;
}

void WD_feed(){ 
	// Antes de escribir el AA hay que desactivar las interrupciones
	//disable_isr();
	disable_isr_fiq();
	WDFEED = 0xAA;						   
  WDFEED = 0x55;
  enable_isr_fiq();	
	//enable_isr ();
	// Volver a activar las interrupciones
}
