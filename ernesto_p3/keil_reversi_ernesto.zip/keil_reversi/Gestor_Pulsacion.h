#ifndef GESTOR_PULSACION_H
#define GESTOR_PULSACION_H
#include <stdbool.h>
void gestor_pulsacion_inicializar_botones();
bool gestor_pulsacion_eint2_comprobar_sigue_pulsado();
bool gestor_pulsacion_eint1_comprobar_sigue_pulsado();
#endif