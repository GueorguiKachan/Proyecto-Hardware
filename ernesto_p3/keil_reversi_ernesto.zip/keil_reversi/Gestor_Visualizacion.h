#ifndef GESTOR_VISUALIZACION_H
#define GESTOR_VISUALIZACION_H
#include <stdint.h>

void init_serial(void);
int sendchar (int ch) ;
void Gvisualizacion_print_array(int lista[]);
void mensaje_inicial_print();
void enviar_string(char *mensaje,int tam);
void continuar_mensaje();
void enviar_mensaje_final(int minutos,int segundos,int razon,int tiempo_computo);
#endif