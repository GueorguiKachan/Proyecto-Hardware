#ifndef RTC_H
#define RTC_H

void RTC_init();
int RTC_leer_minutos();
int RTC_leer_segundos();

#endif