/* guarda para evitar inclusiones m�ltiples ("include guard") */
#ifndef SUDOKU_H_2021
#define SUDOKU_H_2021

#include <inttypes.h>
#include <stdbool.h>
#include <stdlib.h>
#include "celda.h"

/* Tama�os de la cuadricula */
/* Se utilizan 16 columnas para facilitar la visualizaci�n */
enum {NUM_FILAS = 9,
      PADDING = 7,
      NUM_COLUMNAS = NUM_FILAS + PADDING};

/* Definiciones para valores muy utilizados */
enum {FALSE = 0, TRUE = 1};

typedef uint16_t CELDA;

int candidatos_actualizar_c(CELDA cuadricula[NUM_FILAS][NUM_COLUMNAS]);

void
candidatos_propagar_c(CELDA cuadricula[NUM_FILAS][NUM_COLUMNAS],
                             uint8_t fila, uint8_t columna);

void sudoku_init();

bool sudoku_anyadir_valor_nuevo(uint8_t fila_actual, uint8_t columna_actual, uint8_t valor_nuevo);

void sudoku_borrar_valor(uint8_t fila_actual, uint8_t columna_actual);
bool sudoku_fila_columna_validos(uint8_t valor_fila,uint8_t valor_columna);

uint8_t sudoku_get_valor_celda(uint8_t valor_fila,uint8_t valor_columna);
uint8_t sudoku_get_valor_error(uint8_t valor_fila,uint8_t valor_columna);
uint16_t sudoku_get_valor_candidatos(uint8_t valor_fila,uint8_t valor_columna);

char *sudoku_print();
void generar_evento_sudoku();
int siguiente_caracter_sudoku();
bool existe_siguiente_caracter_sudoku();
void introducir_posible_valor(int fila, int columna, int valor);
void sudoku_confirmar_valor_nuevo();
char * obtener_sudoku();
void sudoku_cancelar_valor_nuevo();
int tamanyo_string();
bool final_partida_sudoku();
int sudoku_tiempo_computo();
bool sudoku_cancelar_jugada();
#endif /* SUDOKU_H_2021 */

