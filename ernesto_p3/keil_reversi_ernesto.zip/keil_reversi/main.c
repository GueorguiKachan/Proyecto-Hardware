                  
#include <LPC210x.H>                       /* LPC210x definitions */
//#include "Timer.h"
//#include "Power_management.h"
//#include "boton_eint0.h"
#include <stdio.h>
#include "timers.h"
#include "eventos.h"
#include "cola.h"
#include "Gestor_Alarmas.h"
#include "Gestor_Energia.h"

//#pragma import(__use_no_semihosting_swi)

// Nota: wait es una espera activa. Se puede eliminar poniendo el procesador en modo iddle. Probad a hacerlo
/*void wait (void)  {                         //wait function 
  unsigned int i;

  i = temporizador_leer(); // reads the number of previous timer IRQs
	//temporizador_parar();
  //while ((i + 50) != temporizador_leer());              //waits for 10 interrupts, i.e. 50ms 
	while (500 != temporizador_leer());
}*/

int main (void) {
	int evento;
  // Programar alarma peri�dica para encolar un evento de tipo tempPeriodico
  temporizador_periodico(59); // 59+1/60MHz creo que son 1us !!!!!!!!!!!!!! Igual habr�a que hacer una funci�n en gestor Alarmas para programar esto
  while(1){
		
    if(hay_eventos()){ // Comprueba si en la cola hay eventos nuevos. Si los hay --> switch-case
			evento = leerIDMasAntiguo();
			if(evento == 0){
				 nuevoEvento(leerDatosMasAntiguo());
			}
			else if(evento == 1){}
			else if(evento == 2){}
			else if(evento == 3){
				disparaEventos(1000); // El temporizador interrumpe cada 1us = 1000ms (en el Gestor los tiempos de alarma se guardan en ms)
				break;
			}
			else{}
      /*switch(evento)
			{
        case 7: // Programar una alarma con la info extra del evento
          nuevoEvento(leerDatosMasAntiguo());
					break;
        case pulsacion1: 
					break;
        case pulsacion2:
					break;
        case tempPeriodico: // Establecer un temporizador periodico
          disparaEventos(1000); // El temporizador interrumpe cada 1us = 1000ms (en el Gestor los tiempos de alarma se guardan en ms)
					break;
				case compruebaSuelta1: //Comprobar si se ha soltado la tecla 
          break;
					//eint1_comprobar();
        case compruebaSuelta2:
          //eint2_comprobar();
					break;
				default:
					break;
      }*/
		}
      else{
        //PM_idle(); // Poner el procesador en modo reposo hasta que llegue la interrupci�n del temporizador
      }
    }
  

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
  //unsigned int j,num;                           /* LED var */
	 
	//eint0_init(); // activates EINT0 interrupts
	// Nota la gesti�n del GPIO vosotros la debe�s hacer en GPIO.c no en el main o en el reversi
	//IODIR 		= 0x00FF0000;					//Set LED pins as outputs
	//IOCLR 		= 0x00FF0000;					//Initialices the outputs to 0

	// bucle para comprobar el funcionamiento del bot�n. El objetivo es comprobar que se lleva bien la cuenta de pulsaciones
	// con s�lo una interrupci�n EXTINT0 por pulsaci�n
	// en este proyecto no va a funcionar porque la interrupci�n se activa por nivel y no se ha a�adido la gesti�n necesaria para ue s�lo interrumpa una vez.
	/*while (eint0_read_count() < 4){
		PM_power_down(); // de aqu� s�lo despertamos si hay pulsaci�n
		};*/	
// bucle que realiza un blink de leds cada 50ms	 

//timer0_init(); // generates an interrupt every 0,05ms and increments timeval0		
	//temporizador_iniciar(); // generates an interrupt every 0,05ms and increments timeval0
	//temporizador_empezar();
	
	//while (1)  {                                  /* Loop forever */
	//for (j = 0x010000; j < 0x800000; j <<= 1) { /* Blink LED 0,1,2,3,4,5,6 */
      // Nota la gesti�n del GPIO vosotros la debe�s hacer en GPIO.c no en el main o en el reversi
			//IOSET = j;                               /* Turn on LED */
      //wait ();                                  /* call wait function */
      //IOCLR = j;                               /* Turn off LED */
			//printf("e");
			//temporizador_parar();
  //}
  //for (j = 0x800000; j > 0x010000; j >>=1 ) { /* Blink LED 7,6,5,4,3,2,1 */
      // Nota la gesti�n del GPIO vosotros la debe�s hacer en GPIO.c no en el main o en el reversi
		//	IOSET = j;                               /* Turn on LED */
      //wait ();                                  /* call wait function */
      //IOCLR = j;                               /* Turn off LED */
   //}
		/*for(j=0;j < 10000;j++){
		//printf("Esperando");
			j = j+3-4+2;
		}
		
		//num=temporizador_leer();
		//printf("Numero %d",num);
  //}
	while (10 != temporizador_leer()){
		int p = T1PC;
		num=p;
	};
	
	num = temporizador_parar();
	while(num != 20){num = num +1;}
	temporizador_iniciar();
	temporizador_empezar();
	
	while (10 <= temporizador_leer());*/
	
//}
}

	

//int main (void) {
//  	
//  reversi8();
//	
//}
