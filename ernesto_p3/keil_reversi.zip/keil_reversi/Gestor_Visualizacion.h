#ifndef GESTOR_VISUALIZACION_H
#define GESTOR_VISUALIZACION_H

void gestor_visualizacion_init(void);
int gestor_visualizacion_sendchar(int ch) ;
void gestor_visualizacion_print_array(int lista[]);
void gestor_visualizacion_print_mensaje_inicial();
void gestor_visualizacion_enviar_string(char *mensaje,int tam);
void gestor_visualizacion_continuar_mensaje();
void gestor_visualizacion_enviar_mensaje_final(int minutos, int segundos,int razon,int tiempo_computo);
#endif