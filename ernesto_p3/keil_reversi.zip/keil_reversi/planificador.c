#include <LPC210x.H>                       /* LPC210x definitions */
#include <stdio.h>
#include "timers.h"
#include "eventos.h"
#include "cola.h"
#include "Gestor_Alarmas.h"
#include "Gestor_Energia.h"
#include "Gestor_Pulsacion.h"
#include "Gestor_IO.h"
#include "sudoku_2021.h"
#include "Gestor_Visualizacion.h"
#include "RTC.h"
#include "WT.h"
int main (void) {
bool power_down_active = false;
	
while(1){
	bool idle_recien_apagado = false;
	int tiempoAntes;
	int tiempo; // Guardar el valor de antes en esta variable y luego hacer tiempo = leer_tiempo - tiempo
	uint8_t evento_id_cola;
	uint32_t datos_auxiliares_cola;
	bool pulsacion1_recien_pulsado = true;
	bool pulsacion2_recien_pulsado = true;
	bool partida_nueva = true; 
	bool parpadear_gpio = false;
	bool three_seconds_to_validate_play = false;
	char * res;
	int tam;
	int wt_reinicio = 0;
	
	//gestor_visualizacion_print_mensaje_inicial(;
	GestorAlarmaInit();
  WD_init();
	WD_feed();
	RTC_init();
	temporizador_iniciar();
	temporizador_empezar();
	sudoku_init();
	gestorIO_iniciar();
	gestor_pulsacion_inicializar_botones();
	gestor_energia_init();
	gestor_visualizacion_init();
	gestor_visualizacion_print_mensaje_inicial();
	while(1){
    if(cola_hay_eventos()){ // Comprueba si en la cola hay eventos nuevos. Si los hay averigua cual es
			
			disable_isr_fiq();
			evento_id_cola = cola_leer_evento_mas_antiguo();
			datos_auxiliares_cola = cola_leer_datos_aux_mas_antiguo();
			enable_isr_fiq();	
			if(evento_id_cola == alarmaSet){														// Programar alarma nueva
				gestor_alarma_nueva_alarma(datos_auxiliares_cola);
			}
			else if(evento_id_cola == pulsacion1){											// Se pulsa el bot�n eint1
				if(!gestorIO_comprobar_final_partida() && !final_partida_sudoku()){
				if(!power_down_active){
					if(pulsacion1_recien_pulsado){
						if(!partida_nueva){
							// ------Boton de aceptar-------
							// Escribir el valor en el sudoku
							// Recalcular candidatos (viene dentro de sudoku confirmar)
							// Mostrar por pantalla 
							// Cancelar el parpadeo 
							// Cancelar la alarma de 3 segundos
							// ------Boton de aceptar-------
							gestor_alarma_desactivar_alarma_aceptar_jugada();
							three_seconds_to_validate_play = false;
							sudoku_confirmar_valor_nuevo();
							gestor_visualizacion_enviar_string(sudoku_print(),tamanyo_string());
							
							//tiempoAntes = clock_gettime();
							//falta comprobar si todo es 0
							//sudoku_anyadir_valor_nuevo(gestorIO_leer_fila(),gestorIO_leer_columna(),gestorIO_leer_valor_nuevo());
							//tiempo = clock_gettime() - tiempoAntes;
							//gestorIO_activar_validacion(); // Tras 1 segundo, apagar bit de validaci�n.!!!!!!!!!!!!!!!!!! Visualizar el cambio aqui directamente?
							// Habr�a que hacer que si la celda es pista se encienda el bit de error mientras se mantenga pulsado el boton
						}
						else{ 
							//power_down_active = false;
							//gestorIO_escribir_idle(0);// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Esto no sobra?
							gestor_visualizacion_enviar_string(sudoku_print(),0);
							partida_nueva = false;
						}
						pulsacion1_recien_pulsado = false;
					}
				}else{
					//Generar tablero
					power_down_active = false;
							gestorIO_escribir_idle(0);
				}
			}else{
				if(final_partida_sudoku()){
					gestor_visualizacion_enviar_mensaje_final(RTC_leer_minutos(),RTC_leer_segundos(),2,sudoku_tiempo_computo());
				}else{
					gestor_visualizacion_enviar_mensaje_final(RTC_leer_minutos(),RTC_leer_segundos(),1,sudoku_tiempo_computo());
				}
				cola_eliminar_evento_mas_antiguo();
				continue;
			}
				if (!gestor_pulsacion_eint1_comprobar_sigue_pulsado()){
					pulsacion1_recien_pulsado = true;
				}
			}
			else if(evento_id_cola == pulsacion2){										// Se pulsa el bot�n eint2
					if(!partida_nueva){
						if (pulsacion2_recien_pulsado){ //Si se ha dejado de pulsar
							if(!power_down_active){ //Comprobar si se ha pulsado el bot�n para salir de modo Power Down
								
								// ------Boton de rechazar-------
								// Mostrar por pantalla el sudoku anterior
								// Cancelar el parpadeo 
								// Cancelar la alarma de 3 segundos
								// ------Boton de rechazar-------
								gestor_alarma_desactivar_alarma_aceptar_jugada();
								three_seconds_to_validate_play = false;
								sudoku_cancelar_valor_nuevo();
								gestor_visualizacion_enviar_string(obtener_sudoku(),0);
								
								//tiempoAntes = clock_gettime();
							//	sudoku_borrar_valor(gestorIO_leer_fila(),gestorIO_leer_columna());
								//tiempo = clock_gettime() - tiempoAntes;
								//gestorIO_activar_validacion();
							}
							else{ 
								power_down_active = false;
								gestorIO_escribir_idle(0);// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Esto no sobra?
							}
							pulsacion2_recien_pulsado = false;
						}
					}else{
						//Generar tablero
						gestor_visualizacion_enviar_string(sudoku_print(),0);
						partida_nueva = false;
					}
				if (!gestor_pulsacion_eint2_comprobar_sigue_pulsado()){
						pulsacion2_recien_pulsado = true;
				}
			}
			else if(evento_id_cola == tempPeriodico){                 // Temporizador peri�dico. Comprobar si alguna alarma salta
				gestor_alarma_restar_tiempo_alarmas_programadas();
				if (three_seconds_to_validate_play){
					gestorIO_escribir_idle(1 - gestorIO_leer_idle());
				}else{gestorIO_escribir_idle(0);}
			}
			else if(evento_id_cola == PDown){													// Poner el sistema en modo PowerDown
				power_down_active = true;
				gestorIO_escribir_idle(1); // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!Esto no sobra?
				PM_power_down();
			}
			else if(evento_id_cola == apagarValidacion){								// Tras un segundo apagar el bit de validacion
				idle_recien_apagado = true;
				gestorIO_apagar_validacion();
			}
			else if(evento_id_cola == nuevo_caracter){
				gestorIO_guardar_nuevo_caracter(datos_auxiliares_cola);
			}
			else if(evento_id_cola == cout_caracter){
				gestor_visualizacion_continuar_mensaje();
			}
			else if(evento_id_cola == jugada){
				if(!partida_nueva){
		
					uint8_t fila = (datos_auxiliares_cola >> 16) & 0xFF;
					uint8_t col = (datos_auxiliares_cola >> 8) & 0xFF;
					uint8_t valor_nuevo = datos_auxiliares_cola & 0xFF;
					introducir_posible_valor(fila, col, valor_nuevo);
					gestor_visualizacion_enviar_string(obtener_sudoku(),0);
					gestor_alarma_poner_alarma_aceptar_jugada();
					three_seconds_to_validate_play = true;
				}else{
					// Generar tablero
					gestor_visualizacion_enviar_string(sudoku_print(),0);
					partida_nueva = false;
				}
			}
			else if(evento_id_cola == fin_jugada){ // No se ha decidido que hacer con la jugada. Pues se cancela por lento
					three_seconds_to_validate_play = false;
					sudoku_cancelar_valor_nuevo();
					gestor_visualizacion_enviar_string(obtener_sudoku(),0);
			}
			else if(evento_id_cola == fin_partida){
				cola_eliminar_evento_mas_antiguo();
				break;
			}
			else if(evento_id_cola == wt_reiniciar_juego){
				wt_reinicio = 1;
				break;
			}
			else{} // El valor del evento no coincide con ninguno de los registrados
				//WD_feed();
			cola_eliminar_evento_mas_antiguo();
		}
      else{
				//gestorIO_escribir_idle(1);
        PM_idle(); // Poner el procesador en modo reposo hasta que llegue la interrupci�n del temporizador
				//gestorIO_escribir_idle(0);
				enable_isr();
			}
    }
		//gestor_visualizacion_enviar_mensaje_final(RTC_leer_minutos(),RTC_leer_segundos());
		if(wt_reinicio != 1){
			temporizador_parar();
			PM_power_down(); // Modo Power Down cuando acaba una partida, hasta que se pulse un bot�n
			power_down_active = true;
		}
	}
}