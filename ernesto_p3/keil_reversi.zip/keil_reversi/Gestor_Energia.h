#ifndef GESTOR_ENERGIA_H
#define GESTOR_ENERGIA_H
void gestor_energia_init();
void PM_power_down (void);  
extern void Switch_to_PLL();
void PM_idle(void);
#endif