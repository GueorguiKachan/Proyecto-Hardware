// Circular Queue implementation in C

#include <stdio.h>
#include "cola.h"
#include "timers.h"

#define SIZE 32
struct elemento{
	uint8_t ID_evento;
	uint32_t auxData;
	uint32_t tiempo;
};

static struct elemento items[SIZE];
volatile int front = -1, rear = -1;

// Check if the queue is full
int lleno () {
  if ((front == rear + 1) || (front == 0 && rear == SIZE - 1)) return 1;
  return 0;
}

// Check if the queue is empty
int vacio () {
  if (front == -1) return 1;
  return 0;
}

// Adding an element
void cola_guardar_eventos(uint8_t ID_evento, uint32_t auxData) {
	//Nos interesa que no haga overflow
	struct elemento aux;
  while(lleno()){
	}
	if (front == -1) front = 0;
	rear = (rear + 1) % SIZE;
	aux.ID_evento = ID_evento;
	aux.auxData = auxData;
	aux.tiempo = clock_gettime(); //poner marca de tiempo
	items[rear] = aux;
}

// Removing an element
bool cola_eliminar_evento_mas_antiguo() {
  
  if (vacio()) {
    return false;
  } else {
    if (front == rear) {
      front = -1;
      rear = -1;
    } 
    // Q has only one element, so we reset the 
    // queue after dequeing it. ?
    else {
      front = (front + 1) % SIZE;
    }
    return true;
  }
}

//funcion que compruebe si la cola tiene nuevos eventos(supongo que se refiere a que no est� vacia)
bool cola_hay_eventos(){
	return !vacio();
}

uint8_t cola_leer_evento_mas_antiguo(){
  return items[front].ID_evento;
}
uint32_t cola_leer_datos_aux_mas_antiguo(){
  return items[front].auxData;
}
uint32_t leerTiempoMasAntiguo(){
  return  items[front].tiempo;
}

void cola_vaciar(){
	front = -1, rear = -1;
}