void timer0_init(int periodo);
unsigned int timer0_read_int_count(void);
void temporizador_iniciar();
void temporizador_empezar();
unsigned int temporizador_leer();
unsigned int temporizador_parar(void);
