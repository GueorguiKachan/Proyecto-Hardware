#ifndef GESTOR_ALARMAS_H
#define GESTOR_ALARMAS_H

#include <stdint.h>
void GestorAlarmaInit();
void gestor_alarma_restar_tiempo_alarmas_programadas();
void gestor_alarma_nueva_alarma(uint32_t nuevaAlarma);
void gestor_alarma_poner_alarma_aceptar_jugada();
void desactivar_alarma_aceptar_jugada();
void gestor_alarma_poner_alarma_power_down();
#endif