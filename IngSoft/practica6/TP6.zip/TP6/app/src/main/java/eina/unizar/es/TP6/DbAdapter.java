package eina.unizar.es.TP6;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import eina.unizar.es.*;

/**
 * Simple notes database access helper class. Defines the basic CRUD operations
 * for the notepad example, and gives the ability to list all notes as well as
 * retrieve or modify a specific note.
 *
 * This has been improved from the first version of this tutorial through the
 * addition of better error handling and also using returning a Cursor instead
 * of using a collection of inner classes (which is less scalable and not
 * recommended).
 */
public class DbAdapter {

    public static final String PRODUCT_KEY_NAME = "name";
    public static final String PRODUCT_KEY_WEIGHT = "weight";
    public static final String PRODUCT_KEY_ROWID = "_id";
    public static final String PRODUCT_KEY_DESCRIPTION = "description";
    public static final String PRODUCT_KEY_PRICE = "price";

    public static final String ORDER_KEY_CLIENT_NAME = "name";
    public static final String ORDER_KEY_PHONE= "phone";
    public static final String ORDER_KEY_DATE = "date";
    public static final String ORDER_KEY_ROWID = "_id";

    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static final String PRODUCT_DATABASE_TABLE = "products";
    private static final String ORDER_DATABASE_TABLE = "orders";

    private final Context mCtx;

    /**
     * Constructor - takes the context to allow the database to be
     * opened/created
     *
     * @param ctx the Context within which to work
     */
    public DbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    /**
     * Open the notes database. If it cannot be opened, try to create a new
     * instance of the database. If it cannot be created, throw an exception to
     * signal the failure
     *
     * @return this (self reference, allowing this to be chained in an
     *         initialization call)
     * @throws SQLException if the database could be neither opened or created
     */
    public DbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        // mCtx.deleteDatabase("products");
        //System.out.println("Aqui");
        //mDbHelper.onUpgrade(mDb,1,2);
        return this;
    }

    public void close() {
        mDbHelper.close();
    }


    /**
     * Create a new note using the title and body provided. If the note is
     * successfully created return the new rowId for that note, otherwise return
     * a -1 to indicate failure.
     *
     * @param title the title of the note
     * @param body the body of the note
     * @return rowId or -1 if failed
     */
    public long createProduct(String name, String description, float weight, float price) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(PRODUCT_KEY_NAME, name);
        initialValues.put(PRODUCT_KEY_DESCRIPTION, description);
        initialValues.put(PRODUCT_KEY_WEIGHT, weight);
        initialValues.put(PRODUCT_KEY_PRICE, price);
        System.out.println("Peso y precio "+weight + " "+ price);
        return mDb.insert(PRODUCT_DATABASE_TABLE, null, initialValues);
    }

    public long createOrder(String clientsName, int phone, String date) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(ORDER_KEY_CLIENT_NAME, clientsName);
        initialValues.put(ORDER_KEY_PHONE, phone);
        initialValues.put(ORDER_KEY_DATE, date);


        System.out.println("Peso y precio "+date + " ");
        return mDb.insert(ORDER_DATABASE_TABLE, null, initialValues);
    }

    /**
     * Delete the note with the given rowId
     *
     * @param rowId id of note to delete
     * @return true if deleted, false otherwise
     */
    public boolean deleteProduct(long rowId) {

        return mDb.delete(PRODUCT_DATABASE_TABLE, PRODUCT_KEY_ROWID + "=" + rowId, null) > 0;
    }

    public boolean deleteOrder(long rowId) {

        return mDb.delete(ORDER_DATABASE_TABLE, ORDER_KEY_ROWID + "=" + rowId, null) > 0;
    }

    /**
     * Return a Cursor over the list of all notes in the database
     *
     * @return Cursor over all notes
     */
    public Cursor fetchAllProducts() {

        return mDb.query(PRODUCT_DATABASE_TABLE, new String[] {PRODUCT_KEY_ROWID, PRODUCT_KEY_NAME,
                PRODUCT_KEY_DESCRIPTION}, null, null, null, null, PRODUCT_KEY_NAME);
    }

    public Cursor fetchByPrice() {

        return mDb.query(PRODUCT_DATABASE_TABLE, new String[] {PRODUCT_KEY_ROWID, PRODUCT_KEY_NAME,
                PRODUCT_KEY_DESCRIPTION}, null, null, null, null, PRODUCT_KEY_WEIGHT);
    }
    public Cursor fetchByWeight() {

        return mDb.query(PRODUCT_DATABASE_TABLE, new String[] {PRODUCT_KEY_ROWID, PRODUCT_KEY_NAME,
                PRODUCT_KEY_DESCRIPTION}, null, null, null, null, PRODUCT_KEY_PRICE);
    }

    public Cursor fetchAllOrders() {

        return mDb.query(ORDER_DATABASE_TABLE, new String[] {ORDER_KEY_ROWID, ORDER_KEY_CLIENT_NAME,
                ORDER_KEY_PHONE}, null, null, null, null, ORDER_KEY_CLIENT_NAME);
    }

    public Cursor fetchByPhone() {

        return mDb.query(ORDER_DATABASE_TABLE, new String[] {ORDER_KEY_ROWID, ORDER_KEY_CLIENT_NAME,
                ORDER_KEY_PHONE}, null, null, null, null, ORDER_KEY_PHONE);
    }
    public Cursor fetchByDate() {

        return mDb.query(ORDER_DATABASE_TABLE, new String[] {ORDER_KEY_ROWID, ORDER_KEY_CLIENT_NAME,
                ORDER_KEY_PHONE}, null, null, null, null, ORDER_KEY_DATE);
    }
    /**
     * Return a Cursor positioned at the note that matches the given rowId
     *
     * @param rowId id of note to retrieve
     * @return Cursor positioned to matching note, if found
     * @throws SQLException if note could not be found/retrieved
     */
    public Cursor fetchProduct(long rowId) throws SQLException {

        Cursor mCursor =

                mDb.query(true, PRODUCT_DATABASE_TABLE, new String[] {PRODUCT_KEY_ROWID,
                                PRODUCT_KEY_NAME, PRODUCT_KEY_DESCRIPTION}, PRODUCT_KEY_ROWID + "=" + rowId, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    public Cursor fetchOrder(long rowId) throws SQLException {
        Cursor mCursor =

                mDb.query(true, ORDER_DATABASE_TABLE, new String[] {ORDER_KEY_ROWID, ORDER_KEY_CLIENT_NAME,
                                ORDER_KEY_PHONE}, ORDER_KEY_ROWID + "=" + rowId, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;
    }

    /**
     * Update the note using the details provided. The note to be updated is
     * specified using the rowId, and it is altered to use the title and body
     * values passed in
     *
     * @param rowId id of note to update
     * @param title value to set note title to
     * @param body value to set note body to
     * @return true if the note was successfully updated, false otherwise
     */
    public boolean updateProduct(long rowId, String name, String description, float weight, float price) {
        ContentValues args = new ContentValues();
        args.put(PRODUCT_KEY_ROWID, rowId);
        args.put(PRODUCT_KEY_NAME, name);
        args.put(PRODUCT_KEY_DESCRIPTION, description);
        args.put(PRODUCT_KEY_WEIGHT, weight);
        args.put(PRODUCT_KEY_PRICE, price);

        return mDb.update(PRODUCT_DATABASE_TABLE, args, PRODUCT_KEY_ROWID + "=" + rowId, null) > 0;
    }

    public boolean updateOrder(long rowId, String clientsName, int phone, String date) {
        ContentValues args = new ContentValues();
        args.put(ORDER_KEY_ROWID, rowId);
        args.put(ORDER_KEY_CLIENT_NAME, clientsName);
        args.put(ORDER_KEY_PHONE, phone);
        args.put(ORDER_KEY_DATE, date);

        return mDb.update(ORDER_DATABASE_TABLE, args, ORDER_KEY_ROWID + "=" + rowId, null) > 0;
    }


    /*public boolean deleteNote2() {

        return mDb.delete(DATABASE_TABLE, null , null) > 0;
    }*/
}