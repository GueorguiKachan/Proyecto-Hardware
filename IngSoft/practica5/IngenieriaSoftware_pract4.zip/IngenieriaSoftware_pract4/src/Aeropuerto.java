import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("6a35c787-0334-4d66-a468-14d2828c53f6")
public class Aeropuerto {
    @objid ("53f0ce1e-705d-4cc5-b07d-a6090c835afc")
    public String Nombre;

    @objid ("06e0e808-2824-4cf8-82f7-da3d23a50dc6")
    public void Limpiar() {
    }

}
