import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("9f4a5b61-6066-452b-98aa-fbc1c19c7d33")
public class Pasajero {
    @objid ("5a9d3704-852e-4b84-9472-933e7933c8f8")
    public String DNI;

    @objid ("31eac283-54fe-4718-8bed-5004307ea29a")
    public String Nombre;

}
