import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("4f8bbdd1-588e-4c6d-a3a3-c6359adac121")
public class Asiento {
    @objid ("ab353559-7dc8-4702-9e3c-3b6a4edfd119")
    public int Numero;

    @objid ("3e1c7ffc-805b-40d4-a173-c9a6d49a4524")
    public void Limpiar() {
    }

}
