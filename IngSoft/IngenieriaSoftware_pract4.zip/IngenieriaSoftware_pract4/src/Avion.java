import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("091a690d-71cd-4804-8eca-5dd2a134dd8e")
public class Avion {
    @objid ("fbe6293b-fc82-452c-a0b7-f0e6c5180b59")
    public String codigoAvion;

    @objid ("f6d63523-500d-4911-8dd8-03f53c300804")
    public String Modelo;

    @objid ("27cba39c-d9e0-46fd-9a52-2f267737aa1b")
    public void Despegar(final Aeropuerto aeropuerto) {
    }

    @objid ("0326119c-3564-481c-b7cc-db1440ccd56f")
    public void Aterrizar(final Aeropuerto aeropuerto) {
    }

    @objid ("87d28939-9112-4ece-9cb9-aeca3b0aecd3")
    public void Limpiar() {
    }

}
