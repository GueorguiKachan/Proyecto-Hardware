package eina.unizar.es.TP6;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Test {
    private final DbAdapter notes;
    public Test(DbAdapter notes) {
        this.notes = notes;
    }

    public void pruebasUnitariasCajaNegra(){
        android.util.Log.d("PRUEBAS", "El resultado de la primera prueba unitaria de crear producto ha sido: "+
                notes.createProduct("chocolate", "hacendado", 14,2));
        android.util.Log.d("PRUEBAS", "El resultado de la segunda prueba unitaria de crear producto ha sido: "+
                notes.createProduct(null, "hacendado", 14,2));
        android.util.Log.d("PRUEBAS", "El resultado de la tercera prueba unitaria de crear producto ha sido: "+
                notes.createProduct("chocolate", null, 14,2));
        android.util.Log.d("PRUEBAS", "El resultado de la primera prueba unitaria de borrar producto ha sido: "+
                notes.deleteProduct(1));
        android.util.Log.d("PRUEBAS", "El resultado de la segunda prueba unitaria de borrar producto ha sido: "+
                notes.deleteProduct(0));
        android.util.Log.d("PRUEBAS", "El resultado de la primera prueba unitaria de update producto ha sido: "+
                notes.updateProduct(2, "chocolate","hacendado", 14,2));
        android.util.Log.d("PRUEBAS", "El resultado de la segunda prueba unitaria de update producto ha sido: "+
                notes.updateProduct(2, null,"hacendado", 14,2));
        android.util.Log.d("PRUEBAS", "El resultado de la tercera prueba unitaria de update producto ha sido: "+
                notes.updateProduct(2, "chocolate",null, 14,2));
        android.util.Log.d("PRUEBAS", "El resultado de la cuarta prueba unitaria de update producto ha sido: "+
                notes.updateProduct(0, "chocolate","hacendado", 14,2));
    }

    public void pruebaVolumen(){
        String pre = new String();
        pre = "PRE-";
        for (int i = 0; i <1000; i++){
            notes.createProduct(pre + i,"",0,0);
        }
    }

    public void deshacerPruebaVolumen(){
        String pre = new String();
        pre = "PRE-";
        for (int i = 0; i <1000; i++){
            notes.deleteProductByTitle(pre + i);
        }
    }

    public void pruebaSobreCarga(){
        //String aux = "a";
        String texto = "a";
        int tamanyo = texto.length();
        while (true){
            Log.v("PruebaSobrecarga", "tamanyo="+ tamanyo);
            notes.createProduct("sobrecarga - "+ tamanyo, texto,0,0);
            tamanyo += tamanyo;
            texto += texto;
        }
    }
}