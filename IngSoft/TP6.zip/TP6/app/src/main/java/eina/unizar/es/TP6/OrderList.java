package eina.unizar.es.TP6;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import eina.unizar.es.TP6.DbAdapter;


public class OrderList extends AppCompatActivity {

    private static final int ACTIVITY_CREATE=0;
    private static final int ACTIVITY_EDIT=1;
    private static final int LIST_PRODUCTS = 2;

    private static final int INSERT_ID = Menu.FIRST;
    private static final int DELETE_ID = Menu.FIRST + 1;
    private static final int EDIT_ID = Menu.FIRST + 2;
    private static final int SEND_CONFIRMATION_ID = Menu.FIRST + 3;
    private static final int CALCULATE_WEIGHT_ID = Menu.FIRST + 4;
    private static final int CALCULATE_PRICE_ID = Menu.FIRST + 5;
    private static final int PHONE_ORDER = Menu.FIRST + 6;
    private static final int DATE_ORDER = Menu.FIRST + 7;
    private static final int NAME_ORDER = Menu.FIRST + 8;

    private DbAdapter mDbHelper;
    private ListView mList;


    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_list);
        //  setContentView(R.layout.pagina_principal);
        mDbHelper = new DbAdapter(this);
        mDbHelper.open();
        mList = (ListView)findViewById(R.id.list);
        fillData();
        registerForContextMenu(mList);
    }

    private void fillData() {

        // Get all of the notes from the database and create the item list
        Cursor notesCursor = mDbHelper.fetchAllOrders();

        // Create an array to specify the fields we want to display in the list (only TITLE)
        String[] from = new String[] { DbAdapter.ORDER_KEY_CLIENT_NAME };

        // and an array of the fields we want to bind those fields to (in this case just text1)
        int[] to = new int[] {  R.id.name};

        // Now create an array adapter and set it to display using our row
        SimpleCursorAdapter notes =
                new SimpleCursorAdapter(this, R.layout.order_row, notesCursor, from, to);
        mList.setAdapter(notes);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(Menu.NONE, INSERT_ID, Menu.NONE, R.string.menu_insert_order);
        menu.add(Menu.NONE, PHONE_ORDER, Menu.NONE, R.string.phone_order);
        menu.add(Menu.NONE, DATE_ORDER, Menu.NONE, R.string.date_order);
        menu.add(Menu.NONE, NAME_ORDER, Menu.NONE, R.string.name_order);
        return result;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case INSERT_ID:
                createOrder();
                return true;
            case PHONE_ORDER:
                orderPhone();
                return true;
            case DATE_ORDER:
                orderDate();
                return true;
            case NAME_ORDER:
                orderName();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, DELETE_ID, Menu.NONE, R.string.menu_delete_order);
        menu.add(Menu.NONE, EDIT_ID, Menu.NONE, R.string.menu_edit_order);
        menu.add(Menu.NONE, SEND_CONFIRMATION_ID, Menu.NONE, R.string.menu_send_order);
        menu.add(Menu.NONE, CALCULATE_WEIGHT_ID, Menu.NONE, R.string.menu_calc_weight);
        menu.add(Menu.NONE, CALCULATE_PRICE_ID, Menu.NONE, R.string.menu_calc_price);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch(item.getItemId()) {
            case DELETE_ID:
                AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                mDbHelper.deleteOrder(info.id);
                fillData();
                return true;
            case EDIT_ID:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                editOrder(info.position, info.id);
                return true;
            case SEND_CONFIRMATION_ID:

            case CALCULATE_WEIGHT_ID:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                showWeight(info.id);
                return true;
            case CALCULATE_PRICE_ID:
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                showPrice(info.id);
                return true;
        }
        return super.onContextItemSelected(item);
    }

    private void createOrder() {
        Intent i = new Intent(this, OrderEdit.class);
        startActivityForResult(i, ACTIVITY_CREATE);
    }

    protected void editOrder(int position, long id) {
        Intent i = new Intent(this, OrderEdit.class);
        i.putExtra(DbAdapter.ORDER_KEY_ROWID, id);
        startActivityForResult(i, ACTIVITY_EDIT);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        fillData();
    }



    public void orderPhone(){
        //setContentView(R.layout.order_list);
        //  setContentView(R.layout.pagina_principal);
        mDbHelper = new DbAdapter(this);
        mDbHelper.open();
        mList = (ListView)findViewById(R.id.list);
        // Fill data
        Cursor notesCursor = mDbHelper.fetchByPhone();
        String[] from = new String[] { DbAdapter.ORDER_KEY_CLIENT_NAME, DbAdapter.ORDER_KEY_DATE };
        int[] to = new int[] { R.id.name, R.id.date };
        SimpleCursorAdapter notes =
                new SimpleCursorAdapter(this, R.layout.order_row, notesCursor, from, to);
        mList.setAdapter(notes);

        registerForContextMenu(mList);
    }
    public void orderDate(){
        //setContentView(R.layout.order_list);
        //  setContentView(R.layout.pagina_principal);
        mDbHelper = new DbAdapter(this);
        mDbHelper.open();
        mList = (ListView)findViewById(R.id.list);
        // Fill data
        Cursor notesCursor = mDbHelper.fetchByDate();
        String[] from = new String[] { DbAdapter.ORDER_KEY_CLIENT_NAME, DbAdapter.ORDER_KEY_DATE };
        int[] to = new int[] { R.id.name, R.id.date };
        SimpleCursorAdapter notes =
                new SimpleCursorAdapter(this, R.layout.order_row, notesCursor, from, to);
        mList.setAdapter(notes);

        registerForContextMenu(mList);
    }

    public void orderName(){
        //setContentView(R.layout.order_list);
        //  setContentView(R.layout.pagina_principal);
        mDbHelper = new DbAdapter(this);
        mDbHelper.open();
        mList = (ListView)findViewById(R.id.list);
        fillData();
        registerForContextMenu(mList);
    }

    public void showWeight(long id){
        float aux = mDbHelper.calculateWeightOrder(id);
        android.util.Log.d("PRUEBAS", "peso1:"+ aux);
        alert("Weight",Float.toString(aux));
        android.util.Log.d("PRUEBAS", "peso2:"+ aux);
    }

    public void showPrice(long id){
        float aux = mDbHelper.calculatePriceOrder(id);
        android.util.Log.d("PRUEBAS", "precio1:"+ aux);
        alert("Price",Float.toString(aux));
        android.util.Log.d("PRUEBAS", "precio2:"+ aux);
    }

    /*private void alert(String title, String message){
        AlertDialog dlg = new AlertDialog.Builder(OrderList.this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        dialog.dismiss();
                    }
                })
                .create();
    }*/
    private void alert(String title, String body){
        AlertDialog.Builder builder = new AlertDialog.Builder(OrderList.this);
        builder.setTitle(title);
        builder.setMessage(body)
                .setPositiveButton("OK", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        //Toast.makeText(getApplicationContext(), "Eliminamos datos...", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                }).show();
                /*.setNegativeButton("cancel", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which){
                        Toast.makeText(getApplicationContext(),"cancel...",Toast.LENGTH_SHORT).show();
                    }
                }).show();*/
    }

}








