package eina.unizar.es.TP6;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;
import eina.unizar.es.*;
public class SelectAmount extends AppCompatActivity {

    private EditText mAmount;
    //private Long mRowId;
    private DbAdapter mDbHelper;
    private Long id_order;
    private Long id_product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDbHelper = new DbAdapter(this);
        mDbHelper.open();
        //Intent intent = getIntent();
        //id_order = intent.getStringExtra(DbAdapter.ORDER_KEY_ROWID);
        id_order = (savedInstanceState == null) ? null:
                (Long) savedInstanceState.getSerializable(DbAdapter.AMOUNT_KEY_ORDER_ID);
        if (id_order == null) {
            Bundle extras = getIntent().getExtras();
            id_order = (extras != null) ?
                    extras.getLong(DbAdapter.AMOUNT_KEY_ORDER_ID) : null;
        }
        //id_product = intent.getStringExtra(DbAdapter.AMOUNT_KEY_PRODUCT_ID);
        id_product = (savedInstanceState == null) ? null:
                (Long) savedInstanceState.getSerializable(DbAdapter.AMOUNT_KEY_PRODUCT_ID);
        if (id_product == null) {
            Bundle extras = getIntent().getExtras();
            id_product = (extras != null) ?
                    extras.getLong(DbAdapter.AMOUNT_KEY_PRODUCT_ID) : null;
        }
        android.util.Log.d("PRUEBAS", "id_order y id_product = "+id_order +" y " +id_product );
        setContentView(R.layout.select_amount);
        setTitle(R.string.select_amount);

        mAmount = (EditText) findViewById(R.id.amount);
        Button confirmButton = (Button) findViewById(R.id.save_selection);

        confirmButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                setResult(RESULT_OK);
                finish();
            }

        });
    }

    private void populateFields(){

        android.util.Log.d("PRUEBAS", "antes de fetchAmount");
        android.util.Log.d("PRUEBAS", "en populateFields id_order y id_product = " + id_order +" y "+id_product);
        //mDbHelper.createAmount(10,8,12);
        Cursor cursor = mDbHelper.fetchAmount(id_order, id_product);
        android.util.Log.d("PRUEBAS", "en populateFields DESPues de fetchamount");
        if (cursor.getCount() >0) {
            android.util.Log.d("PRUEBAS", "dentro del primer if");
            startManagingCursor(cursor);
            if (cursor.getCount() > 0){
                android.util.Log.d("PRUEBAS", "dentro del segundo if");
                android.util.Log.d("PRUEBAS", cursor.getString(cursor.getColumnIndexOrThrow(DbAdapter.AMOUNT_KEY_AMOUNT)));
            mAmount.setText(cursor.getString(
                    cursor.getColumnIndexOrThrow(DbAdapter.AMOUNT_KEY_AMOUNT)));
        }}
        else{
            android.util.Log.d("PRUEBAS", "despues de fetchAmount");
            mAmount.setText("0");
        }
    }
    @Override
    protected void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        saveState();
        outState.putSerializable(DbAdapter.AMOUNT_KEY_ORDER_ID, id_order);
        outState.putSerializable(DbAdapter.AMOUNT_KEY_PRODUCT_ID, id_product);
    }

    @Override
    protected void onPause(){
        super.onPause();
        saveState();
    }

    @Override
    protected void onResume(){
        super.onResume();
        populateFields();
    }

    private void saveState(){
        Bundle extras = getIntent().getExtras();
        Long _id_order = (extras != null) ?
                extras.getLong(DbAdapter.AMOUNT_KEY_ORDER_ID) : null;
        Long _id_product = (extras != null) ?
                extras.getLong(DbAdapter.AMOUNT_KEY_PRODUCT_ID) : null;
        int amount = Integer.parseInt(mAmount.getText().toString());

        android.util.Log.d("PRUEBAS", "_id_order y _id_product y amount = "+_id_order +" y " +_id_product +" y " +amount);
        System.out.println("Order y product "+_id_order + " "+ _id_product);
        if (mDbHelper.fetchAmount(_id_order, _id_product).getCount() <= 0) {
            android.util.Log.d("PRUEBAS", "fetchallamounts ha dado null");
            //Create
             mDbHelper.createAmount(_id_order, _id_product, amount);
        }else{
            android.util.Log.d("PRUEBAS", "fetchallamounts ha dado algo");
            //update
            mDbHelper.updateAmount(_id_order, _id_product, amount);
        }
    }
}
