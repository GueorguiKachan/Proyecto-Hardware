import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("855f52b2-5aca-46ae-b879-72c2e961c13a")
public class Linea Aerea {
    @objid ("3b58bff7-ba38-4548-857c-32382527b0aa")
    public String Nombre;

}
