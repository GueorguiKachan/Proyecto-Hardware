import android.os.Bundle;;
import bundle;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("f2468a79-e655-4bdc-bd31-f7c22e7aff0e")
public class Notepadv1 {
    @objid ("f143ca6f-edd1-4599-b30b-419d18d1feea")
    private int mNotNumber;

    @objid ("3d8b197f-164d-49fc-b0ed-e6557f72110b")
    private ListView mList;

    @objid ("f549ffdf-c018-4fd2-84de-ed74425ac8f8")
    private NotesDbAdapter mDbHelper;

    @objid ("9b11f2fc-11c3-4237-8b4c-710892590c59")
    public int INSERT_ID;

    @objid ("941cce0a-d3f7-4193-b796-7206438e6da9")
    public void onCreate() {
    }

    @objid ("db6cfb3c-1035-4af6-8bca-66f8de1a274c")
    public boolean onCreateOptionsMenu() {
        // TODO Auto-generated return
        return false;
    }

    @objid ("a7509033-d6ff-49c7-91e8-1650e81db293")
    public boolean onOptionsItemSelected() {
        // TODO Auto-generated return
        return false;
    }

    @objid ("eb308135-6425-4fd6-9adc-1d44782131f0")
    private void createNote() {
    }

    @objid ("d7b8b437-4f4b-4a5d-8393-92c51dff2222")
    private void fillData() {
    }

}
