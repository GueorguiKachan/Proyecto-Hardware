import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("26d8b147-50c1-4cf5-a446-376171b7c465")
public class Vuelo {
    @objid ("fbff39d8-7965-4800-b7b2-5d71145415ca")
    public String fecha;

    @objid ("a2eb49e7-2d51-4c5f-8d8c-12b26ed849e9")
    public String codigoVuelo;

    @objid ("2276e558-86ec-4e6a-a696-8720bae67d50")
    public String Tipo;

    @objid ("ea9988b6-8537-4b7f-b259-056d6648e487")
    public void Cancelar() {
    }

    @objid ("84a31a5b-5141-4ef2-bdb1-b1b530a1ab3a")
    public void Retrasar(final String tiempo) {
    }

    @objid ("70ac4cf8-b76e-46aa-8512-e344821bd8c8")
    public void Reservar(final Pasajero pasajero, final Asiento asiento) {
    }

}
