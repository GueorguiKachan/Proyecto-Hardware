import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("cdedba17-2438-456f-a326-fce873f6f806")
public class Piloto {
    @objid ("aba07627-1733-43b3-a2b8-f16e34066869")
    public String DNI;

    @objid ("036e28a5-6ce9-45e4-b8a9-3539359d9026")
    public String Nombre;

}
