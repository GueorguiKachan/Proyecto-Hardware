package es.unizar.eina.notepadv3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Simple notes database access helper class. Defines the basic CRUD operations
 * for the notepad example, and gives the ability to list all notes as well as
 * retrieve or modify a specific note.
 *
 * This has been improved from the first version of this tutorial through the
 * addition of better error handling and also using returning a Cursor instead
 * of using a collection of inner classes (which is less scalable and not
 * recommended).
 */
public class NotesDbAdapter {

    public static final String KEY_NAME = "name";
    public static final String KEY_WEIGHT = "weight";
    public static final String KEY_ROWID = "_id";
    public static final String KEY_DESCRIPTION = "description";
    public static final String KEY_PRICE = "price";

    public static final String KEY_CLIENT_NAME = "name";
    public static final String KEY_PHONE= "phone";
    public static final String KEY_DATE = "date";
    public static final String KEY_ORDER_ROWID = "_id";

    private DatabaseHelper mDbHelper;
    private SQLiteDatabase mDb;

    private static final String DATABASE_TABLE = "products";
    private static final String DATABASE_TABLE1 = "orders";

    private final Context mCtx;

    /**
     * Constructor - takes the context to allow the database to be
     * opened/created
     *
     * @param ctx the Context within which to work
     */
    public NotesDbAdapter(Context ctx) {
        this.mCtx = ctx;
    }

    /**
     * Open the notes database. If it cannot be opened, try to create a new
     * instance of the database. If it cannot be created, throw an exception to
     * signal the failure
     *
     * @return this (self reference, allowing this to be chained in an
     *         initialization call)
     * @throws SQLException if the database could be neither opened or created
     */
    public NotesDbAdapter open() throws SQLException {
        mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
       // mCtx.deleteDatabase("products");
        //System.out.println("Aqui");
        //mDbHelper.onUpgrade(mDb,1,2);
        return this;
    }

    public void close() {
        mDbHelper.close();
    }


    /**
     * Create a new note using the title and body provided. If the note is
     * successfully created return the new rowId for that note, otherwise return
     * a -1 to indicate failure.
     *
     * @param title the title of the note
     * @param body the body of the note
     * @return rowId or -1 if failed
     */
    public long createNote(String name, String weight, String description, String price) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_NAME, name);
        initialValues.put(KEY_DESCRIPTION, description);
        initialValues.put(KEY_WEIGHT, weight);
        initialValues.put(KEY_PRICE, price);
        System.out.println("Peso y precio "+weight + " "+ price);
        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }

    public long createOrder(String clientsName, String phone, String date) {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_CLIENT_NAME, clientsName);
        initialValues.put(KEY_PHONE, phone);
        initialValues.put(KEY_DATE, date);


        System.out.println("Peso y precio "+date + " ");
        return mDb.insert(DATABASE_TABLE1, null, initialValues);
    }

    /**
     * Delete the note with the given rowId
     *
     * @param rowId id of note to delete
     * @return true if deleted, false otherwise
     */
    public boolean deleteNote(long rowId) {

        return mDb.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null) > 0;
    }

    public boolean deleteOrder(long rowId) {

        return mDb.delete(DATABASE_TABLE1, KEY_ROWID + "=" + rowId, null) > 0;
    }

    /**
     * Return a Cursor over the list of all notes in the database
     *
     * @return Cursor over all notes
     */
    public Cursor fetchAllNotes() {

        return mDb.query(DATABASE_TABLE, new String[] {KEY_ROWID, KEY_NAME,
                KEY_DESCRIPTION}, null, null, null, null, KEY_NAME);
    }

    public Cursor fetchByPrice() {

        return mDb.query(DATABASE_TABLE, new String[] {KEY_ROWID, KEY_NAME,
                KEY_DESCRIPTION}, null, null, null, null, KEY_WEIGHT);
    }
    public Cursor fetchByWeight() {

        return mDb.query(DATABASE_TABLE, new String[] {KEY_ROWID, KEY_NAME,
                KEY_DESCRIPTION}, null, null, null, null, KEY_PRICE);
    }

    public Cursor fetchAllOrders() {

        return mDb.query(DATABASE_TABLE1, new String[] {KEY_ORDER_ROWID, KEY_CLIENT_NAME,
                KEY_PHONE}, null, null, null, null, KEY_CLIENT_NAME);
    }

    public Cursor fetchByPhone() {

        return mDb.query(DATABASE_TABLE1, new String[] {KEY_ORDER_ROWID, KEY_CLIENT_NAME,
                KEY_PHONE}, null, null, null, null, KEY_PHONE);
    }
    public Cursor fetchByDate() {

        return mDb.query(DATABASE_TABLE1, new String[] {KEY_ORDER_ROWID, KEY_CLIENT_NAME,
                KEY_PHONE}, null, null, null, null, KEY_DATE);
    }
    /**
     * Return a Cursor positioned at the note that matches the given rowId
     *
     * @param rowId id of note to retrieve
     * @return Cursor positioned to matching note, if found
     * @throws SQLException if note could not be found/retrieved
     */
    public Cursor fetchNote(long rowId) throws SQLException {

        Cursor mCursor =

                mDb.query(true, DATABASE_TABLE, new String[] {KEY_ROWID,
                                KEY_NAME, KEY_DESCRIPTION}, KEY_ROWID + "=" + rowId, null,
                        null, null, null, null);
        if (mCursor != null) {
            mCursor.moveToFirst();
        }
        return mCursor;

    }

    /**
     * Update the note using the details provided. The note to be updated is
     * specified using the rowId, and it is altered to use the title and body
     * values passed in
     *
     * @param rowId id of note to update
     * @param title value to set note title to
     * @param body value to set note body to
     * @return true if the note was successfully updated, false otherwise
     */
    public boolean updateNote(long rowId, String name, String weight, String description, String price) {
        ContentValues args = new ContentValues();
        args.put(KEY_ROWID, rowId);
        args.put(KEY_NAME, name);
        args.put(KEY_DESCRIPTION, description);
        args.put(KEY_WEIGHT, weight);
        args.put(KEY_PRICE, price);

        return mDb.update(DATABASE_TABLE, args, KEY_ROWID + "=" + rowId, null) > 0;
    }

    public boolean updateOrder(long rowId, String clientsName, String phone, String date) {
        ContentValues args = new ContentValues();
        args.put(KEY_ORDER_ROWID, rowId);
        args.put(KEY_CLIENT_NAME, clientsName);
        args.put(KEY_DESCRIPTION, phone);
        args.put(KEY_WEIGHT, date);

        return mDb.update(DATABASE_TABLE1, args, KEY_ORDER_ROWID + "=" + rowId, null) > 0;
    }


    public boolean deleteNote2() {

        return mDb.delete(DATABASE_TABLE, null , null) > 0;
    }
}