package es.unizar.eina.notepadv3;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "data";
    private static final int DATABASE_VERSION = 2;

    private static final String TAG = "DatabaseHelper";

    /**
     * Database creation sql statement
     */
    private static final String DATABASE_CREATE =
            "create table products (_id integer primary key autoincrement, name text not null, description text not null, weight text not null, price text not null);";

    private static final String DATABASE_CREATE1 =
            "create table orders (_id integer primary key autoincrement, name text not null, phone text not null, date text not null);";
    private static final String DATABASE_CREATE2 =
            "create table productOrders (_id integer primary key autoincrement, product_id integer not null, order_id integer not null, num text not null," +
                    "FOREIGN KEY (product_id) REFERENCES products(_id)," +
                    "FOREIGN KEY (order_id) REFERENCES orders(_id));";

    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("Yoooooooo "+DATABASE_CREATE);

        db.execSQL(DATABASE_CREATE);
        db.execSQL(DATABASE_CREATE1);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
                + newVersion + ", which will destroy all old data");
        db.execSQL("DROP TABLE IF EXISTS products");
        db.execSQL("DROP TABLE IF EXISTS orders");
        onCreate(db);
    }

    
}